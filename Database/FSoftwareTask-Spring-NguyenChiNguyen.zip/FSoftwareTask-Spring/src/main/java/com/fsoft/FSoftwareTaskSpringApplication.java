package com.fsoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FSoftwareTaskSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(FSoftwareTaskSpringApplication.class, args);
    }

}
