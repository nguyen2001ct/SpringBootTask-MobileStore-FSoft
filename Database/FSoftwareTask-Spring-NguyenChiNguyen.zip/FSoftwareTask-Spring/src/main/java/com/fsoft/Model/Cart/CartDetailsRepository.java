package com.fsoft.Model.Cart;

import com.fsoft.Model.Cart.CartDetails;
import org.springframework.data.repository.CrudRepository;

public interface CartDetailsRepository extends CrudRepository<CartDetails,Integer> {
}
