package com.fsoft.Model.Cart;

import com.fsoft.Model.Cart.Cart;
import org.springframework.data.repository.CrudRepository;

public interface CartRepository  extends CrudRepository<Cart,Integer> {
}
